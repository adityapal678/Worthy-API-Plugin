<?php

class Worthy_Keap_Oauth_Route extends WP_REST_Controller {

  public function register_routes() {
    $version = '1';
    $namespace = 'worthy/v' . $version;
    $base = 'keap';
    register_rest_route( $namespace, '/' . $base . '/request-access', array(
      array(
        'methods' => WP_REST_Server::READABLE,
        'callback' => array ( $this, 'request_access_token' ),
        'permission_callback' => '__return_true'
      ),
    ) );
    register_rest_route( $namespace, '/' . $base . '/refresh-token', array(
      array(
        'methods' => WP_REST_Server::READABLE,
        'callback' => array ( $this, 'refresh_access_token' ),
        'permission_callback' => '__return_true'
      ),
    ) );
  }
  
  public function request_access_token( $request ) {
    $options = get_option( 'worthy_api_options' );

    $client_id = $options['worthy_keap_client_id'];
    $client_secret = $options['worthy_keap_client_secret'];
    $code = $request->get_param( 'code' );
    $save_access_token_url = get_site_url() . '/wp-json/worthy/v1/keap/request-access';
    $url = $options['worthy_keap_token_url'];

    $response = wp_remote_post(
      $options['worthy_keap_token_url'],
      array(
        'headers' => array(
          'Content-Type' => 'application/x-www-form-urlencoded'
        ),
        'body' => array(
          'client_id' => $client_id,
          'client_secret' => $client_secret,
          'code' => $code,
          'grant_type' => 'authorization_code',
          'redirect_uri' => $save_access_token_url
        )
      )
    );

    $response_body = json_decode($response['body']);
    $response_array = (array) $response_body;
    $access_token = $response_array['access_token'];
    $refresh_token = $response_array['refresh_token'];

    global $wpdb;
    $table_name = $wpdb->prefix . "worthy_oauth_client_credentials";
    $sql = "
      SELECT * FROM $table_name WHERE client_name='keap'
    ";
    $data = array(
      'client_name' => 'keap',
      'access_token' => $access_token,
      'refresh_token' => $refresh_token,
      'updated' => current_time( 'mysql' )
    );

    $keap_details = $wpdb->get_results( $sql );
    $first = (array) $keap_details[0];

    $first_id = null;
    $where = null;
    if(!empty($first)) {
      $first_id = $first['id'];
      $where = array('id' => $first_id);
      $wpdb->update( $table_name, $data, $where );
    } else {
      $wpdb->insert( $table_name, $data );
    }

    return new WP_REST_Response( array(
      'message' => 'access token and refresh token saved. You may now close this page',
    ), 200 );
  }

  public function refresh_access_token( $request ) {
    $options = get_option( 'worthy_api_options' );

    $client_id = $options['worthy_keap_client_id'];
    $client_secret = $options['worthy_keap_client_secret'];
    $base64_encoded = base64_encode($client_id . ':' . $client_secret);
    $authorization_header = "Basic " . $base64_encoded;

    global $wpdb;
    $table_name = $wpdb->prefix . "worthy_oauth_client_credentials";
    $sql = "
      SELECT * FROM $table_name WHERE client_name='keap'
    ";

    $keap_options = $wpdb->get_results( $sql );
    $keap_option = (array) $keap_options[0];
    $refresh_token = $keap_option['refresh_token'];

    $response = wp_remote_post(
      $options['worthy_keap_token_url'],
      array(
        'headers' => array(
          'Content-Type' => 'application/x-www-form-urlencoded',
          'Authorization' => $authorization_header
        ),
        'body' => array(
          'grant_type' => 'refresh_token',
          'refresh_token' => $refresh_token
        )
      )
    );

    $response_body = json_decode($response['body'], true);
    $new_access_token = $response_body['access_token'];
    $new_refresh_token = $response_body['refresh_token'];

    $data = array(
      'client_name' => 'keap',
      'access_token' => $new_access_token,
      'refresh_token' => $new_refresh_token,
      'updated' => current_time( 'mysql' )
    );

    $keap_option_id = $keap_option['id'];
    $where = array('id' => $keap_option_id);
    $saved_keap_options = $wpdb->update( $table_name, $data, $where );

    if ($saved_keap_options === false) {
      return new WP_REST_Response( array(
        'message' => 'Error refreshing the access token. Refresh token is now invalid. Please reauthorize the application.',
        'status' => '500'
      ), 500);
    } else {
      return new WP_REST_Response( array(
        'message' => 'Successfully updated access and refresh tokens.',
        'status' => '200'
      ), 200);
    }
  }

  public function get_items( $request ) {}

  public function create_item( $request ) {}

  public function get_item( $request ) {

    return new WP_REST_Response( $membership, 200 );
  }

  public function update_item( $request ) {}

  public function delete_item( $request ) {}

  // dont need any of these function right now
  public function get_items_permissions_check( $request ) {}
  public function get_item_permissions_check( $request ) {}
  public function create_item_permissions_check( $request ) {}
  public function update_item_permissions_check( $request ) {}
  public function delete_item_permissions_check( $request ) {}

  protected function prepare_item_for_database( $request ) {}
  public function prepare_item_for_response( $item, $request ) {}
  public function get_collection_params() {}
}
