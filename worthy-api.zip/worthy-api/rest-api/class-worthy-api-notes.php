<?php

class Worthy_Notes_Route extends WP_REST_Controller {

  public function register_routes() {
    $version = '1';
    $namespace = 'worthy/v' . $version;
    $base = 'notes';
    register_rest_route( $namespace, '/users/(?P<user_id>[\d]+)/lessons/(?P<lesson_id>[\d]+)/' . $base, array(
      array(
        'methods' => WP_REST_Server::READABLE,
        'callback' => array ( $this, 'get_items' ),
        'permission_callback' => array( $this, 'logged_in_only' )
      ),
      array(
        'methods' => WP_REST_Server::CREATABLE,
        'callback' => array ( $this, 'create_item' ),
        'permission_callback' => array( $this, 'logged_in_only' )
      )
    ) );
    register_rest_route( $namespace, '/users/(?P<user_id>[\d]+)/lessons/(?P<lesson_id>[\d]+)/' . $base . '/(?P<note_id>[\d]+)', array(
      array(
        'methods' => WP_REST_Server::READABLE,
        'callback' => array ( $this, 'get_item' ),
        'permission_callback' => array( $this, 'logged_in_only' )
      ),
      array(
        'methods' => WP_REST_Server::EDITABLE,
        'callback' => array ( $this, 'update_item' ),
        'permission_callback' => array( $this, 'logged_in_only' )
      ),
      array(
        'methods' => WP_REST_Server::DELETABLE,
        'callback' => array ( $this, 'delete_item' ),
        'permission_callback' => array( $this, 'logged_in_only' )
      ),
    ) );
  }

  public function get_items( $request ) {
    global $wpdb;
    $user_id = $request->get_param('user_id');
    $lesson_id = $request->get_param('lesson_id');
    $table_name = $wpdb->prefix . "worthy_lesson_notes";
    $sql = "
      SELECT * FROM $table_name where user_id=$user_id and post_id=$lesson_id
    ";

    $notes = $wpdb->get_results( $sql );

    return new WP_REST_Response( $notes, 200 );
  }

  public function get_item( $request ) {
    global $wpdb;
    $user_id = $request->get_param('user_id'); // use for checking if user actually own this thing
    $lesson_id = $request->get_param('lesson_id');
    $note_id = $request->get_param('note_id');
    $table_name = $wpdb->prefix . "worthy_lesson_notes";
    $sql = "
      SELECT * FROM $table_name where id=$note_id
    ";

    $note = $wpdb->get_results( $sql );

    return new WP_REST_Response( $note, 200 );
  }

  public function create_item( $request ) {
    global $wpdb;
    $json_params = $request->get_json_params();
    $user_id = $request->get_param('user_id');
    $lesson_id = $request->get_param('lesson_id');
    $table_name = $wpdb->prefix . "worthy_lesson_notes";
    $data = array(
      'post_id' => $lesson_id,
      'user_id' => $user_id,
      'note' => strval($json_params['note']),
    );

    $notes = $wpdb->insert( $table_name, $data );

    return new WP_REST_Response( $notes, 201 );
  }

  public function update_item( $request ) {
    global $wpdb;
    $json_params = get_json_params();
    $user_id = $request->get_param('user_id'); // use for checking if user actually own this thing
    $lesson_id = $request->get_param('lesson_id');
    $note_id = $request->get_param('note_id');
    $table_name = $wpdb->prefix . "worthy_lesson_notes";
    $data = array(
      'note' => strval($json_params['note']),
    );
    $where = array(
      'id' => $note_id
    );

    $note = $wpdb->update( $table_name, $data, $where );

    if (false === $note) {
      return new WP_REST_Response( 'Error updating note', 500 );
    }
    return new WP_REST_Response( $note, 204 );
  }

  public function delete_item( $request ) {
    global $wpdb;
    $user_id = $request->get_param('user_id'); // use for checking if user actually own this thing
    $lesson_id = $request->get_param('lesson_id');
    $note_id = $request->get_param('note_id');
    $table_name = $wpdb->prefix . "worthy_lesson_notes";

    $where = array(
      'id' => $note_id
    );
    
    $deleted_note = $wpdb->delete( $table_name, $where );
  }

  public function logged_in_only( $request ) {
    return is_user_logged_in();
  }

  public function get_items_permissions_check( $request ) {}
  public function get_item_permissions_check( $request ) {}
  public function create_item_permissions_check( $request ) {}
  public function update_item_permissions_check( $request ) {}
  public function delete_item_permissions_check( $request ) {}

  protected function prepare_item_for_database( $request ) {}
  public function prepare_item_for_response( $item, $request ) {}
  public function get_collection_params() {}
}
