<?php

class Worthy_Course_Vimeo_Route extends WP_REST_Controller
{
    public function register_routes()
    {
        $version = '1';
        $namespace = 'worthy/v' . $version;
        $base = 'vimeo';

        register_rest_route($namespace, '/' . $base . '/request-access', array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array($this, 'request_access_token'),
                'permission_callback' => '__return_true'
            ),
        ));
        register_rest_route($namespace, $base, array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_vimeo_videos'),
            'permission_callback' => '__return_true'
        ));
        register_rest_route($namespace, '/tags/' . $base, array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'get_courses_by_tags'),
            'permission_callback' => '__return_true'
        ));
    }



    public function request_access_token($request)
    {
        $client_id = '2a802bb6f92d65071f9facecb8adc78064d569bf';
        $client_secret = 'Qe2GhNO0n5lJugosXIm5I6byKkwlmYpWOkpRLE+9eGSHGicJBzIoGXxLqXYQhaVmE9wMPb3I77XU3tlPddtVqp7ehkXT1OEPnNV7x17Mo/4HQfTGh0YVkt8krr4bRmC7';

        $body = array(
            'grant_type' => 'client_credentials',
            'scope' => 'public private'
        );
        $headers = array(
            'Authorization' => 'basic ' . base64_encode($client_id . ':' . $client_secret),
            'Content-Type' => 'application/json',
            'Accept' => 'application/vnd.vimeo.*+json;version=3.4'
        );
        $url = 'https://api.vimeo.com/oauth/authorize/client';
        $body = wp_json_encode($body);

        // return new WP_REST_Response($body);

        $options = [
            'body'        => $body,
            'headers'     => $headers,
        ];

        $response = wp_remote_post($url, $options);
        $result = json_decode($response['body']);
        
        

        global $wpdb;
        $table_name = $wpdb->prefix . "worthy_oauth_client_credentials";
        $sql = "
          SELECT * FROM $table_name WHERE client_name='vimeo'
        ";

        $vimeo_details = $wpdb->get_results($sql);
        $first = (array) $vimeo_details[0];

        $token =  $result->access_token;
        $updated_time = current_time('mysql');

        $data = array(
            'client_name' => 'vimeo',
            'access_token' => $token,
            'updated' => $updated_time
        );

        $first_id = null;
        $where = null;
        if (!empty($first)) {
            $first_id = $first['id'];
            $where = array('id' => $first_id);
            $wpdb->update($table_name, $data, $where);
        } else {
            $wpdb->insert($table_name, $data);
        }

        return new WP_REST_Response(array(
            'message' => 'access token and refresh token saved. You may now close this page',
        ), 200);
    }

    /**
     * Helper
     * Get vimeo Token from db
     *
     * @return mixed|null
     */
    public function get_admin_token_from_db()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . "worthy_oauth_client_credentials";
        $sql = "SELECT * FROM " . $table_name . " WHERE client_name='vimeo'";
        $vimeo_details = $wpdb->get_results($sql);

        $first = (array)$vimeo_details[0];
        $access_token = null;

        if (!empty($first)) {
            $access_token = $first['access_token'];
        }
        return $access_token;
    }


    public function get_vimeo_videos($request)
    {
        $time = $request->get_params()['time'];
        $access_token = $this->get_admin_token_from_db();

        // $url = 'https://api.vimeo.com/users/34621292/videos';
        $url = 'https://api.vimeo.com/users/34621292/projects/4863873/videos';

        // return new WP_REST_Response($time);

        $response = wp_remote_get(
            $url,
            array(
                'headers' => array(
                    'Accept' => 'application/json, */*',
                    'Authorization' => 'Bearer ' . $access_token
                )
            )
        );

        $videos = json_decode($response['body'], true);
        $videos_data = $videos['data'];
        

        $video_detail = [];
        foreach ($videos_data as $data) {
            
            $updated_time = 0;
            if($time == 5){ 
                $updated_time = $data['duration'] < $time * 60; 
            }else if($time == 10){
                $updated_time = $data['duration'] < 600 && $data['duration'] > 300;     
            }else if($time == 15){
                $updated_time = $data['duration'] < 900 && $data['duration'] > 600;
            }else if($time == 20){
                $updated_time = $data['duration'] < 1200 && $data['duration'] > 900;
            }else if($time == 25){
                $updated_time = $data['duration'] < 1500 && $data['duration'] > 1200;    
            }
            
            if ( $updated_time || $time==="" || $time===0 || $time===null) {
                
                $uri = explode(':', $data['uri']);
                
                
                $data = array(
                    'name' => $data['name'],
                    'uri' =>  $uri[0],
                    'duration' =>  $data['duration'],
                    'embed' => $data['embed']['html'],
                    'picture' => $data['pictures']['sizes'][3]
                );
                array_push($video_detail, $data);
            }
        }
        return new WP_REST_Response($video_detail);
    }


} // End class
