<?php

class Worthy_Course_Route extends WP_REST_Controller
{
    public function register_routes()
    {
        $version = '1';
        $namespace = 'worthy/v' . $version;
        $base = 'courses';

        register_rest_route($namespace, $base, array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_courses'),
            'permission_callback' => '__return_true'
        ));

        register_rest_route($namespace, '/users/(?P<id>[\d]+)/' . $base.'/list', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'list_all_courses_by_userid'),
            'permission_callback' => '__return_true'
        ));

        register_rest_route($namespace, $base . '/(?P<id>[\d]+)/', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_single_course_by_id'),
            'permission_callback' => '__return_true'
        ));
        
         register_rest_route($namespace, '/tags/'. $base , array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'get_courses_by_tags'),
            'permission_callback' => '__return_true'
        ));
        
         register_rest_route($namespace, '/tags/topics'  , array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'get_topics_by_tags'),
            'permission_callback' => '__return_true'
        ));

        register_rest_route($namespace, $base . '/categories', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_courses_by_cateogy'),
            'permission_callback' => '__return_true'
        ));

        register_rest_route($namespace, '/users/(?P<id>[\d]+)/' . $base . '/progress', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_courses_progress'),
            'permission_callback' => '__return_true'
        ));

        register_rest_route($namespace, '/users/(?P<id>[\d]+)/' . $base, array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_courses_user_enrolled'),
            'permission_callback' => '__return_true'
        ));

        register_rest_route($namespace, $base . '/lessons/media-link/', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_download_link'),
            'permission_callback' => '__return_true'
        ));
        
        register_rest_route($namespace, '/users/(?P<id>[\d]+)/lesson-complete', array(
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => array($this, 'course_lesson_completed'),
            'permission_callback' => '__return_true'
        ));
        
        register_rest_route($namespace,  $base . '/course_tags', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_course_tags'),
            'permission_callback' => '__return_true'
        ));
        
        register_rest_route($namespace,  '/topics', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_topics'),
            'permission_callback' => '__return_true'
        ));
        
        register_rest_route($namespace,  $base . '/topic_tags', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_topic_tags'),
            'permission_callback' => '__return_true'
        ));

    }
    
    
    
    

    /**
     * Helper
     * Get Admin Token from db
     *
     * @return mixed|null
     */
    public function get_admin_token_from_db($table_name)
    {
        global $wpdb;
        $sql = "SELECT * FROM " . $table_name . " WHERE client_name='admin'";
        $admin_details = $wpdb->get_results($sql);

        $first = (array)$admin_details[0];
        $access_token = null;

        if (!empty($first)) {
            $access_token = $first['access_token'];
        }
        return $access_token;
    }
    
    /**
     * Get all Tags helper function
     */
    public function all_tags(){
        $tags = get_terms([
            'taxonomy'  => 'ld_course_tag',
            'hide_empty'    => false
        ]);
        
        return $tags;
    }
    
    /**
     * Get all Topic Tags helper function
     */
    public function all_topic_tags()
    {
        $tags = get_terms([
            'taxonomy'  => 'ld_topic_tag',
            'hide_empty'    => false
        ]);

        return $tags;
    }



    /**
     * Helper
     * Getting Username/Password form config file
     * first validate token if exist
     * second create token if not exist
     *
     * @return mixed
     */
    public function get_admin_token()
    {
        global $wpdb;
        $urlparts = parse_url(home_url());
        $scheme = $urlparts['scheme'];
        $domain = $urlparts['host'];
        $wordpress_url = $scheme . '://' . $domain . '/wp-json';

        $token_url = $wordpress_url . '/jwt-auth/v1/token';

        $tablename = $wpdb->prefix . "worthy_oauth_client_credentials";

        $token = $this->get_admin_token_from_db($tablename);

        $token_info = wp_remote_post(
            $token_url . '/validate',
            array(
                'headers' => array(
                    'Accept' => 'application/json, */*',
                    'Content-Type' => 'application/json; charset=UTF-8',
                    'Authorization' => 'Bearer ' . $token
                ),

            )
        );

        $body = json_decode($token_info['body'], true);
        $token_valid = $body['code'] === 'jwt_auth_valid_token';

        if ($token && $token_valid) {
            return $token;
        } else {
            $username = USERNAME;
            $password = PASSWORD;

            $token_data = wp_remote_post(
                $token_url,
                array(
                    'headers' => array(
                        'Accept' => 'application/json, */*',
                        'Content-Type' => 'application/json; charset=UTF-8'
                    ),
                    'body' => json_encode(array(
                        "username" => $username,
                        "password" => $password
                    ))
                )
            );

            $body = json_decode($token_data['body'], true);
            $token = $body['token'];

            $client_name = "admin"; //string value use: %s
            $sql = $wpdb->prepare("INSERT INTO " . $tablename . "(`access_token`, `client_name`) values (%s, %s)", $token, $client_name);
            $wpdb->query($sql);

            return $token;
        }
    }
    
    
     public function get_courses_by_tags($request){
        $tag_ids = $request->get_json_params()['tags'];
        $args = array( 
            'post_type' => 'sfwd-courses',
            'posts_per_page' => -1,
            'tax_query' => array(
                array(
                    'taxonomy' => 'ld_course_tag',
                    'field'    => 'term_id',
                    'terms'    => $tag_ids,
                    'operator' => 'IN',
                ),
            ),             
        
        );
       
        $query = new WP_Query( $args );
         //memb_overrideProhibitedAction();
      
        return new WP_REST_Response( $query->get_posts() );


    }
    
    
    public function get_topics_by_tags($request){
    $tag_ids = $request->get_json_params()['tags'];
        $args = array( 
            'post_type' => 'sfwd-topic',
            'posts_per_page' => -1,
            'tax_query' => array(
                array(
                    'taxonomy' => 'ld_topic_tag',
                    'field'    => 'term_id',
                    'terms'    => $tag_ids,
                    'operator' => 'IN',
                ),
            ),             
        
        );
       
        $query = new WP_Query( $args );
      
        return new WP_REST_Response( $query->get_posts() );

    }
    
    
    public function get_topics($request){
        
        $token = $this->get_admin_token();
        $url = home_url();
        $topics_url = $url . '/wp-json/ldlms/v1/sfwd-topic';
        $response = wp_remote_get(
            $topics_url,
            array(
                'headers' => array(
                    'Accept' => 'application/json, */*',
                    'Authorization' => 'Bearer ' . $token
                )
            )
        );
        
        $topics = json_decode($response['body'], true);
        //  return new WP_REST_Response($topics);
        
        $topics_summarized_details = [];
        foreach($topics as $key => $topic){
            
            
            $alltags = $this->all_topic_tags();
            $topictagidwithname = [];

            foreach ($topic['ld_topic_tag'] as $topictag) {
                foreach ($alltags as  $tag) {
                    if ($tag->term_id === $topictag) {

                        $value = array(
                            'id' => $tag->term_id,
                            'name' => $tag->name
                        );
                    }
                }
                $topictagidwithname[] = $value;
            }
            
            
            $topics_summarized_details[$key]['id'] = $topic['id'];
            $topics_summarized_details[$key]['title'] = $topic['title']['rendered'];
            $topics_summarized_details[$key]['content'] = $this->sanitize_text($topic['content']['rendered']);
            $topics_summarized_details[$key]['topic_category'] = $topic['ld_topic_category'];
            $topics_summarized_details[$key]['topic_tagid_with_name'] = $topictagidwithname;
            $topics_summarized_details[$key]['thumbnail'] = get_the_post_thumbnail_url($topic['id']);

            $url = learndash_get_setting($topic['id'], 'lesson_video_url');
            $topics_summarized_details[$key]['video_url'] = $url;
            
            $materials = stripslashes($topic['topic_materials']);
            $dom = new DOMDocument;

            $dom->loadHTML($materials);
            $links = $dom->getElementsByTagName('a');
            $hrefs = [];
            $count = 0;
            foreach ($links as $link) {
                //Extract and show the "href" attribute.
                $hrefs[$count]['text'] = $link->nodeValue;
                $hrefs[$count]['link'] = $link->getAttribute('href');
                $count += 1;
            }

            $topics_summarized_details[$key]['topic_materials'] = $this->sanitize_text($materials);
            $topics_summarized_details[$key]['topic_materials_links'] = $hrefs;
            
        }
        
        return new WP_REST_Response($topics_summarized_details);
    }
    
    
    /**
     * course_lesson_completed
     */
    public function course_lesson_completed($request){

        $lesson_id = $request->get_json_params()['lesson_id'];
        $user_id = $request->get_param('id');

        $user = get_userdata( $user_id );
        if($user === false){
            return new WP_REST_Response(array(
                message=>'User not Found!'
            ),400);
        }

        $result_complete = learndash_approve_assignment( $user_id, $lesson_id );
        
        if(!$result_complete){
            return new WP_REST_Response(array(
                'message'=>'Lesson already completed'
            ), 200);
        }

        return new WP_REST_Response(array(
            'Lesson completed'=>$result_complete
        ), 200);

    }

    /**
     * Get all courses
     *
     * @param $request
     * @return WP_REST_Response
     */
    public function get_courses($request)
    {
        $token = $this->get_admin_token();
        // Get All Courses
        $url = home_url();
        $courses_url = $url . '/wp-json/ldlms/v2/sfwd-courses';
        $response = wp_remote_get(
            $courses_url,
            array(
                'headers' => array(
                    'Accept' => 'application/json, */*',
                    'Authorization' => 'Bearer ' . $token
                )
            )
        );
        $courses = json_decode($response['body'], true);
        $modified_courses = [];
        foreach ($courses as $key => $course) {
            $modified_courses[$key]['id'] = $course['id'];
            $modified_courses[$key]['title'] = $course['title']['rendered'];
            $modified_courses[$key]['excerpt'] = $course['excerpt']['rendered'];
            $modified_courses[$key]['featured_image'] = $course['_links']['wp:featuredmedia'];
        }
        return new WP_REST_Response($modified_courses);
    }
    
    
    public function sanitize_text($text)
    {
        return preg_replace('!\s+!', ' ', str_replace(array("\n"), ' ', trim(strip_tags(html_entity_decode($text)))));
    }

    public function get_course_progress_percentage($completed, $total)
    {
        if ($total == 0) {
            return 0;
        }
        $percentage = ($completed * 100) / $total;
        return number_format((float)$percentage, 2, '.', '');
    }


    /**
     * Get all Tags
     * course tags 
     * ld_course_tag
     */
    public function get_course_tags($request){

        $tags = $this->all_tags();
        
        return new WP_REST_Response($tags);
    }

    /**
     * Get all Topic Tags
     * Topic tags 
     * ld_course_tag
     */
    public function get_topic_tags($request)
    {
        $topic_tags = $this->all_topic_tags();
        return new WP_REST_Response($topic_tags);
    }


    public function get_single_course_by_id($request)
    {

        global $wpdb;
        $course_id = $request->get_param('id');
        $user_id = $request->get_params()['user_id'];

        $token = $this->get_admin_token();
        
        // Get single Course
        $url = home_url();
        $course_url = $url . '/wp-json/ldlms/v2/sfwd-courses/' . $course_id;
        $response = wp_remote_get(
            $course_url,
            array(
                'headers' => array(
                    'Accept' => 'application/json, */*',
                    'Authorization' => 'Bearer ' . $token
                )
            )
        );
        $course = json_decode($response['body'], true);
        
        // return new WP_REST_Response($course);
        
        $progress = learndash_user_get_course_progress( $user_id,  $course_id );
        
        $progress_status = 'not_started';
        if ($progress['completed'] > 0) {
            $progress_status = 'in_progress';
        }
        if ($progress['completed'] == $progress['total'] && $progress['completed'] > 0) {
            $progress_status = 'completed';
        }
        
        
        $percentage = $this->get_course_progress_percentage($progress['completed'], $progress['total']);
        
            $materials = stripslashes($course['materials']['rendered']);
            $dom = new DOMDocument;

            $dom->loadHTML($materials);
            $links = $dom->getElementsByTagName('a');
            $imgs = $dom->getElementsByTagName('img');
            $iframe = $dom->getElementsByTagName('iframe');
            $hrefs = [];
            $count = 0;
            foreach ($links as $link) {
                //Extract and show the "href" attribute.
                $hrefs[$count]['text'] = $link->nodeValue;
                $hrefs[$count]['link'] = $link->getAttribute('href');
                $count += 1;
            }
            $srcs = [];
            $countsrc = 0;
            foreach ($imgs as $img) {
                $srcs[$countsrc]['img'] = $img->getAttribute('src');
                $countsrc += 1;
            }
            
            $lessons = learndash_course_get_lessons($course_id);

            
            $alltags = $this->all_tags();
            $tagidwithname = [];

            foreach ($course['ld_course_tag'] as $coursetag) {
                foreach ($alltags as  $tag) {
                    if ($tag->term_id === $coursetag) {

                        $value = array(
                            'id' => $tag->term_id,
                            'name' => $tag->name
                        );
                    }
                }
                $tagidwithname[] = $value;
            }
            
            
        // check assign courses flas is  true of false
        $assign_courses = learndash_user_get_enrolled_courses($user_id);
        $flag = false;
        foreach ($assign_courses as $courseid) {
            if ($courseid == $course_id) {
                $flag = true;
                break;
            }
        }    
        
        
        $lessons_content=[];
        foreach ($lessons as $index => $lesson) {
                $url = learndash_get_setting($lesson->ID, 'lesson_video_url');
                $lessons[$index]->video_url = $url;
                $lessons[$index]->post_content = $this->sanitize_text($lessons[$index]->post_content);

                $materials = stripslashes(learndash_get_setting($lesson->ID, 'lesson_materials'));
                $dom = new DOMDocument;

                $dom->loadHTML($materials);
                $links = $dom->getElementsByTagName('a');
                $hrefs = [];
                $count = 0;
                foreach ($links as $link) {
                    //Extract and show the "href" attribute.
                    $hrefs[$count]['text'] = $link->nodeValue;
                    $hrefs[$count]['link'] = $link->getAttribute('href');
                    $count += 1;
                }

                $lessons[$index]->materials = $this->sanitize_text($materials);
                $lessons[$index]->materials_links = $hrefs;
            }
        
            // return new WP_REST_Response($progress);
            
            
        $activity_items = $wpdb->get_results(
            $wpdb->prepare('SELECT * FROM ' . esc_sql(LDLMS_DB::get_table_name('user_activity')) . ' WHERE course_id=%d AND user_id=%d AND `activity_type`=\'course\'',$course_id, $user_id ),
            ARRAY_A
        );    

        $activity = date("F j, Y, g:i a", $activity_items[0]['activity_updated']);

        // create array output
        $modified_course = array(
            'id' => $course['id'],
            'title' => $course['title']['rendered'],
            'content' => $this->sanitize_text($course['content']['rendered']),
            'short_description' => $this->sanitize_text($course['excerpt']['rendered']),
            'thumbnail' => get_the_post_thumbnail_url($course['id']),
            'image' => wp_get_attachment_image_src(get_post_thumbnail_id($course['id']), 'full')[0],
            'price' => $course['price_type_closed_price'],
            'course_category' => $course['ld_course_category'],
            'tag_id_with_name'=> $tagidwithname,
            'button_url' => $course['price_type_closed_custom_button_url'],
            'progress' => $progress,
            'last_activity' => $activity,
            'completed_percentage' => $percentage,
            'status'=> $progress_status,
            'flag' => $flag,

            'materials_content' => array(
                'materials' => $this->sanitize_text($materials),
                'course_materials_links' => $hrefs,
                'course_materials_img' => $srcs
            ),
            'lessons' => $lessons,

        );
        

        return new WP_REST_Response($modified_course);
    }

    
    /**
     * Get list of courses by courses
     *
     * @param $request
     * @return WP_REST_Response
     */
    public function list_all_courses_by_userid($request)
    {

        global $wpdb;
        $id = $request->get_param('id'); // need to be dynamic
        $token = $this->get_admin_token();
        $url = home_url();

        $user = get_userdata($id);
        if (!$user) {
            return new WP_REST_Response(array('error' => 'User does not exist'), 404);
        }

        $courses_url = $url . '/wp-json/ldlms/v1/sfwd-courses?per_page=100';
        $response = wp_remote_get(
            $courses_url,
            array(
                'headers' => array(
                    'Accept' => 'application/json, */*',
                    'Authorization' => 'Bearer ' . $token
                )
            )
        );
        $courses = json_decode($response['body'], true);
        
        $enrolled_courses = ld_get_mycourses($id);

        $modified_courses = [];
        foreach ($courses as $key => $course) {
            
            $alltags = $this->all_tags();
            $tagidwithname = [];

            foreach ($course['ld_course_tag'] as $coursetag) {
                foreach ($alltags as  $tag) {
                    if ($tag->term_id === $coursetag) {

                        $value = array(
                            'id' => $tag->term_id,
                            'name' => $tag->name
                        );
                    }
                }
                $tagidwithname[] = $value;
            }
            
            
            $modified_courses[$key]['id'] = $course['id'];
            $modified_courses[$key]['title'] = $course['title']['rendered'];
            $modified_courses[$key]['course_price'] = (int)$course['course_price'];
            $modified_courses[$key]['ld_course_category'] = $course['ld_course_category'];
            $modified_courses[$key]['ld_course_tag_name_with_id'] = $tagidwithname;
            $modified_courses[$key]['button_url'] = $course['custom_button_url'];
            $modified_courses[$key]['short_description'] = $this->sanitize_text($course['excerpt']['rendered']);
            $modified_courses[$key]['image'] = wp_get_attachment_image_src(get_post_thumbnail_id($course['id']), 'full')[0];

            $materials = stripslashes($course['course_materials']);
            $dom = new DOMDocument;

            $dom->loadHTML($materials);
            $links = $dom->getElementsByTagName('a');
            $hrefs = [];
            $count = 0;
            foreach ($links as $link) {
                //Extract and show the "href" attribute.
                $hrefs[$count]['text'] = $link->nodeValue;
                $hrefs[$count]['link'] = $link->getAttribute('href');
                $count += 1;
            }



        }

        $activity_items = $wpdb->get_results(
            $wpdb->prepare('SELECT * FROM ' . esc_sql(LDLMS_DB::get_table_name('user_activity')) . ' WHERE course_id IN (' . implode(', ', $enrolled_courses) . ') AND user_id=%d AND `activity_type`=\'course\'', $id),
            ARRAY_A
        );

        foreach ($modified_courses as $key => $course) {
            $lessons = learndash_get_lesson_list($course['id']);
            
            $course_progress_list = get_user_meta($id, '_sfwd-course_progress', true);

            foreach ($enrolled_courses as $course_id) {
                if ($course['id'] === $course_id) {
                    $lessons_list = learndash_user_get_course_progress($id, $course['id'])['lessons'];
                    
                    $modified_courses[$key]['flag'] = true;
                    // $modified_courses[$key]['progress']['lessons'] = $lessons_list;

                    $progress_detail=[];
                    foreach ($course_progress_list as $course_progress_id => $single_course_progress) {
                        if ($course_progress_id == $course_id) {
                            $progress_detail = $single_course_progress;
                            break;
                        }
                    }
                    
                    // return new WP_REST_Response($progress_detail);
                    if($progress_detail['completed'] === null){
                        $progress_detail['completed'] = 0;
                    }
                    
                    
                    $total_lesson = 0;
                    foreach($modified_courses[$key]['progress']['lessons'] as $lesson){
                        $total_lesson = $total_lesson+1;
                    }
                    

                    $progress_status = 'not_started';
                    if($progress_detail['completed'] > 0){
                        $progress_status = 'in_progress';
                    }
                    if($progress_detail['completed'] == $progress_detail['total'] && $progress_detail['completed'] > 0){
                        $progress_status = 'completed';
                    }
                    
                    $modified_courses[$key]['progress']['status'] = $progress_status;

                    $modified_courses[$key]['progress']['percentage_completed'] = $this->get_course_progress_percentage($progress_detail['completed'], count($lessons_list)) . '%';

                    $course_activity = "";
                    foreach ($activity_items as $activity_item) {
                        if ($activity_item['course_id'] == $course_id) {
                            //$course_activity = gmdate("Y-m-d\TH:i:s\Z", $activity_item['activity_updated']);
                            $course_activity = date("F j, Y, g:i a", $activity_item['activity_updated']);
                            break;
                        }
                    }


                    break;
                } else {
                    $modified_courses[$key]['flag'] = false;
                }
            }
        }


        return new WP_REST_Response($modified_courses);
    }


    /**
     * Get courses enrolled by user
     *
     * @param $request
     * @return WP_REST_Response
     */
    public function get_courses_user_enrolled($request)
    {
        global $wpdb;
        $id = $request->get_param('id'); // need to be dynamic
        $token = $this->get_admin_token();
        $url = home_url();

        $user = get_userdata($id);
        if (!$user) {
            return new WP_REST_Response(array('error' => 'User does not exist'), 404);
        }

        $courses_url = $url . '/wp-json/ldlms/v1/sfwd-courses?per_page=100';
        $response = wp_remote_get(
            $courses_url,
            array(
                'headers' => array(
                    'Accept' => 'application/json, */*',
                    'Authorization' => 'Bearer ' . $token
                )
            )
        );
        $courses = json_decode($response['body'], true);
        
        // return new WP_REST_Response($courses[0]['id']);

        $enrolled_courses = ld_get_mycourses($id);

        $modified_courses = [];
        foreach ($courses as $key => $course) {
            
            
            
            
            $alltags = $this->all_tags();
            $tagidwithname = [];
            
            foreach($course['ld_course_tag'] as $coursetag){
                    foreach($alltags as  $tag){
                        if($tag->term_id === $coursetag){
                         
                             $value = array(
                                'id'=> $tag->term_id,
                                'name'=> $tag->name
                             );
                    
                        }
                    }
                    $tagidwithname[]= $value;
            }
            
            
            
            // return new WP_REST_Response($tagidwithname);
            
            
            $modified_courses[$key]['id'] = $course['id'];
            $modified_courses[$key]['title'] = $course['title']['rendered'];
            $modified_courses[$key]['course_price'] = (int)$course['course_price'];
            $modified_courses[$key]['button_url'] = $course['custom_button_url'];
            //$modified_courses[$key]['course_materials'] = $course['course_materials'];
            $modified_courses[$key]['ld_course_category'] = $course['ld_course_category'];
            // $modified_courses[$key]['ld_course_tag'] = $course['ld_course_tag'];
            $modified_courses[$key]['ld_course_tag_name_with_id'] = $tagidwithname;
            $modified_courses[$key]['content'] = $this->sanitize_text($course['content']['rendered']);
            $modified_courses[$key]['short_description'] = $this->sanitize_text($course['excerpt']['rendered']);
            $modified_courses[$key]['thumbnail'] = get_the_post_thumbnail_url($course['id']);
            $modified_courses[$key]['image'] = wp_get_attachment_image_src(get_post_thumbnail_id($course['id']), 'full')[0];

            $materials = stripslashes($course['course_materials']);
            $dom = new DOMDocument;

            $dom->loadHTML($materials);
            $links = $dom->getElementsByTagName('a');
            $hrefs = [];
            $count = 0;
            foreach ($links as $link) {
                //Extract and show the "href" attribute.
                $hrefs[$count]['text'] = $link->nodeValue;
                $hrefs[$count]['link'] = $link->getAttribute('href');
                $count += 1;
            }

            $modified_courses[$key]['course_materials'] = $this->sanitize_text($materials);
            $modified_courses[$key]['course_materials_links'] = $hrefs;


        }

        $activity_items = $wpdb->get_results(
            $wpdb->prepare('SELECT * FROM ' . esc_sql(LDLMS_DB::get_table_name('user_activity')) . ' WHERE course_id IN (' . implode(', ', $enrolled_courses) . ') AND user_id=%d AND `activity_type`=\'course\'', $id),
            ARRAY_A
        );

        foreach ($modified_courses as $key => $course) {
            $lessons = learndash_get_lesson_list($course['id']);
            foreach ($lessons as $index => $lesson) {
                $url = learndash_get_setting($lesson->ID, 'lesson_video_url');
                $lessons[$index]->video_url = $url;
                $lessons[$index]->post_content = $this->sanitize_text($lessons[$index]->post_content);

                $materials = stripslashes(learndash_get_setting($lesson->ID, 'lesson_materials'));
                $dom = new DOMDocument;

                $dom->loadHTML($materials);
                $links = $dom->getElementsByTagName('a');
                $hrefs = [];
                $count = 0;
                foreach ($links as $link) {
                    //Extract and show the "href" attribute.
                    $hrefs[$count]['text'] = $link->nodeValue;
                    $hrefs[$count]['link'] = $link->getAttribute('href');
                    $count += 1;
                }

                $lessons[$index]->materials = $this->sanitize_text($materials);
                $lessons[$index]->materials_links = $hrefs;
            }

            $modified_courses[$key]['lessons'] = $lessons;

            $course_progress_list = get_user_meta($id, '_sfwd-course_progress', true);

            foreach ($enrolled_courses as $course_id) {
                if ($course['id'] === $course_id) {
                    $lessons_list = learndash_user_get_course_progress($id, $course['id'])['lessons'];
                    
                    $modified_courses[$key]['flag'] = true;
                    $modified_courses[$key]['progress']['lessons'] = $lessons_list;

                    $progress_detail;
                    foreach ($course_progress_list as $course_progress_id => $single_course_progress) {
                        if ($course_progress_id == $course_id) {
                            $progress_detail = $single_course_progress;
                            break;
                        }
                    }
                    
                    // return new WP_REST_Response($progress_detail);
                    if($progress_detail['completed'] === null){
                        $progress_detail['completed'] = 0;
                    }
                    
                    $modified_courses[$key]['progress']['completed'] = $progress_detail['completed'];
                    
                    
                    $total_lesson = 0;
                    foreach($modified_courses[$key]['progress']['lessons'] as $lesson){
                        $total_lesson = $total_lesson+1;
                    }
                    
                    $modified_courses[$key]['progress']['total'] = $total_lesson;
                    
                    $progress_status = 'not_started';
                    if($progress_detail['completed'] > 0){
                        $progress_status = 'in_progress';
                    }
                    if($progress_detail['completed'] == $progress_detail['total'] && $progress_detail['completed'] > 0){
                        $progress_status = 'completed';
                    }
                    
                    $modified_courses[$key]['progress']['status'] = $progress_status;

                    $modified_courses[$key]['progress']['percentage_completed'] = $this->get_course_progress_percentage($progress_detail['completed'], count($lessons_list)) . '%';

                    $course_activity = "";
                    foreach ($activity_items as $activity_item) {
                        if ($activity_item['course_id'] == $course_id) {
                            //$course_activity = gmdate("Y-m-d\TH:i:s\Z", $activity_item['activity_updated']);
                            $course_activity = date("F j, Y, g:i a", $activity_item['activity_updated']);
                            break;
                        }
                    }

                    $modified_courses[$key]['progress']['last_activity'] = $course_activity;

                    break;
                } else {
                    $modified_courses[$key]['flag'] = false;
                }
            }
        }


        return new WP_REST_Response($modified_courses);

    }


    public function get_courses_by_cateogy($request)
    {

        $token = $this->get_admin_token();
        $url = home_url();

        $courses_url = $url . '/wp-json/ldlms/v1/sfwd-courses?per_page=100';
        $response = wp_remote_get(
            $courses_url,
            array(
                'headers' => array(
                    'Accept' => 'application/json, */*',
                    'Authorization' => 'Bearer ' . $token
                )
            )
        );

        $courses = json_decode($response['body'], true);

        $categories = get_categories(array(
            'taxonomy' => 'ld_course_category'
        ));

        $learndash_category = [];

        foreach ($categories as $category) {
            foreach ($courses as $course) {
                if (in_array($category->term_taxonomy_id, $course['ld_course_category'])) {
                    $learndash_category[$category->category_nicename][] = $course['id'];
                }
            }
        }



        return new WP_REST_Response($learndash_category);
    }

//    public function get_courses_progress($request)
//    {
//        $wp_user_id = 71;
//        $token = $this->get_admin_token();
//
//        $progress_url = 'http://localhost/wp-json/ldlms/v2/users/'. $wp_user_id.'/course-progress';
//        $response = wp_remote_get(
//            $progress_url,
//            array(
//                'headers' => array(
//                    'Accept' => 'application/json, */*',
//                    'Authorization' => 'Bearer ' . $token
//                )
//            )
//        );
//        $progress = json_decode($response['body'], true);
//        $modified_courseprogress = [];
//
//        foreach ($progress as $key=>$courseprogress){
//            $modified_courseprogress[$key]['id'] = $courseprogress['course'];
//            $modified_courseprogress[$key]['last_step'] = $courseprogress['last_step'];
//            $modified_courseprogress[$key]['steps_total'] = $courseprogress['steps_total'];
//            $modified_courseprogress[$key]['steps_completed '] = $courseprogress['steps_completed'];
//            $modified_courseprogress[$key]['date_started '] = $courseprogress['date_started'];
//            $modified_courseprogress[$key]['date_completed '] = $courseprogress['date_completed'];
//            $modified_courseprogress[$key]['progress_status '] = $courseprogress['progress_status'];
//        }
//
//        return new WP_REST_Response($modified_courseprogress);
//
//    }


//    public function get_lessons_by_course_id($request) {
//        $course_id = $request->getParams('id');
//
//        $lessons = learndash_get_lesson_list(4864);
//
//        return new WP_REST_Response($lessons, 200);
//    }


    /**
     * Get donwload link from lessons
     *
     * @param $request
     * @return WP_REST_Response
     */
    public function get_download_link($request)
    {
        $lesson_id = $request->getParams('id');

        $token = $this->get_admin_token();

        $lessons_url = 'http://localhost/wp-json/ldlms/v2/sfwd-lessons/' . $lesson_id;
        $response = wp_remote_get(
            $lessons_url,
            array(
                'headers' => array(
                    'Accept' => 'application/json, */*',
                    'Authorization' => 'Bearer ' . $token
                )
            )
        );
        $lessons = json_decode($response['body']);
        return new WP_REST_Response($lessons);
    }


}