<?php

require_once('country-codes.php');

class Worthy_User_Route extends WP_REST_Controller
{

    /**
     * All routes
     */
    public function register_routes()
    {
        $version = '1';
        $namespace = 'worthy/v' . $version;
        $base = 'users';

        //      Get & Create user data
        register_rest_route($namespace, '/' . $base, array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array($this, 'get_items'),
                'permission_callback' => '__return_true'
            ),
            array(
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => array($this, 'create_item'),
                'permission_callback' => '__return_true'
            )
        ));


        //        Get data by id
        register_rest_route($namespace, '/' . $base . '/(?P<id>[\d]+)', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_item'),
            'permission_callback' => '__return_true'
        ));

        //      Edit data by id
        register_rest_route($namespace, '/' . $base . '/(?P<id>[\d]+)', array(
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => array($this, 'update_item'),
            'permission_callback' => '__return_true'
        ));

        //      Post login data with jwt token return
        register_rest_route($namespace, '/login', array(
            'methods' => 'POST',
            'callback' => array($this, 'login'),
            'permission_callback' => '__return_true'
        ));

        //      Reset Password
        register_rest_route($namespace, $base . '/password-reset', array(
            'methods' => 'POST',
            'callback' => array($this, 'reset'),
            'permission_callback' => '__return_true'
        ));


        //        Get tags by keap id
        register_rest_route($namespace, '/' . $base . '/(?P<id>[\d]+)' . '/tags', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_tags'),
            'permission_callback' => '__return_true'
        ));

        //        Update Free Content tag
        register_rest_route($namespace, '/' . $base . '/(?P<id>[\d]+)' . '/add-free-content-tag', array(
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => array($this, 'update_free_content_tags'),
            'permission_callback' => '__return_true'
        ));
        
        //        Avatar Image Upload`1'
        register_rest_route($namespace, '/' . $base . '/(?P<id>[\d]+)' . '/upload-avatar', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'upload_avatar'),
            'permission_callback' => '__return_true'
        ));

        //        Avatar Image Upload`1'
        register_rest_route($namespace, '/' . $base . '/(?P<id>[\d]+)' . '/remove-avatar', array(
            'methods' => WP_REST_Server::DELETABLE,
            'callback' => array($this, 'remove_avatar'),
            'permission_callback' => '__return_true'
        ));

        //        Get Orders/transactions list by keap id
        register_rest_route($namespace, '/' . $base . '/(?P<id>[\d]+)' . '/orders', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_billing_detail'),
            'permission_callback' => '__return_true'
        ));

        //        Get Credit Card Details
        //        /contacts/{contactId}/creditCards
        register_rest_route($namespace, '/' . $base . '/(?P<id>[\d]+)' . '/creditcard', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_creditcard_detail'),
            'permission_callback' => '__return_true'
        ));
        //        /contacts/{contactId}/invoices
        register_rest_route($namespace, '/' . $base . '/(?P<id>[\d]+)' . '/invoices', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_invoices'),
            'permission_callback' => '__return_true'
        ));
    }

    // getting Keap access token from local db
    public function get_keap_token()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . "worthy_oauth_client_credentials";
        $sql = "
      SELECT * FROM $table_name WHERE client_name='keap'
    ";
        $keap_details = $wpdb->get_results($sql);
        $first = (array)$keap_details[0];
        $access_token = null;

        if (!empty($first)) {
            $access_token = $first['access_token'];
        }
        return $access_token;
    }

    // Merge existing user data if given user data is not provided or blank
    public function merge_user_data($new_data, $old_data)
    {
        $data;
        if (!empty($new_data)) {
            $data = $new_data;
        } else {
            if (is_null($old_data) || strlen($old_data) < 1) {
                $data = "";
            } else {
                $data = $old_data;
            }
        }
        return $data;
    }

    // get user authorized by keap access token
    public function get_data_by_id($url, $keap_access_token)
    {
        $response = wp_remote_get(
           $url,
            array(
                'headers' => array(
                    'Accept' => 'application/json, */*',
                    'Authorization' => 'Bearer ' . $keap_access_token
                )
            )
        );
        return $response;
    }


    public function get_primary_email($email_addresses) {
        $primary_email;

        foreach ($email_addresses as $email_single) {
            if ($email_single['field'] == 'EMAIL1') {
                $primary_email = $email_single['email'];
            }
        }

        return $primary_email;
    }

    /**
     * User Login
     *
     * @param $request
     * @return WP_REST_Response
     */
    public function login($request)
    {
        global $GLOBALS;
        $countries = $GLOBALS['countries'];
        
        $json_params = $request->get_json_params();
        $password = $json_params['password'];
        $email = $json_params['email'];
        $urlparts = parse_url(home_url());
        $scheme = $urlparts['scheme'];
        $domain = $urlparts['host'];
        $wordpress_url = $scheme . '://' . $domain . '/wp-json';

        $token_url = $wordpress_url . '/jwt-auth/v1/token';

        $user = get_user_by('email', $email);
        $user_login = $user->user_login;

        if (!$user) {
            return new WP_REST_Response(array(
                'error' => 'User Not Found!'
            ), 404);
        }

        $access_token = $this->get_keap_token();

        $logged_in_user = wp_remote_post(
            $token_url,
            array(
                'headers' => array(
                    'Accept' => 'application/json, */*',
                    'Content-Type' => 'application/json; charset=UTF-8'
                ),
                'body' => json_encode(array(
                    "username" => $user_login,
                    "password" => $password
                ))
            )
        );

        if(!$logged_in_user){
            return new WP_REST_Response('Invalid user/password');
        }
        
        
        $user_data = json_decode($logged_in_user['body'], true);
        
        // return new WP_REST_Response($user_data);

        if (!$user_data) {
            return new WP_REST_Response(array(
                'error' => 'Invalid Credentials'
            ), 400);
        }
        $user_id = $user_data['user_id'];
        $keap_id = get_user_meta($user_id, 'infusionsoft_user_id')[0];

        $contacts_url = 'https://api.infusionsoft.com/crm/rest/v1/contacts/' . $keap_id;
        $response = $this->get_data_by_id($contacts_url, $access_token);
        $body = json_decode($response['body'], true);
        $code = $response['response']['code'];

        if ($code !== 200) {
            return new WP_REST_Response(array('error' => $response['response']['message']), $code);
        }

        // Adding user avatar to response data if available
        $user_avatar = get_user_meta($user_id, 'user_avatar')[0];
        if ($user_avatar) {
            $user_data['user_avatar'] = $user_avatar;
        }

        $user_data['keap_details'] = array(
            'id' => $body['id'],
            'emails' => $body['email_addresses'],
            'addresses' => $body['addresses'],
            'tagIds' => $body['tag_ids'],
            'firstName' => $body['given_name'],
            'lastName' => $body['family_name'],
            'phoneNumbers' => $body['phone_numbers']

        );
    
        $response_country_code = $user_data['keap_details']['addresses'][0]['country_code'];
        
        $modified_country_code = array_search($response_country_code, $countries);
        
        $user_data['keap_details']['addresses'][0]['country_code'] = $modified_country_code;
        
        return new WP_REST_Response(array('user_data' => $user_data), 200);

    }

    /**
     * Password Reset
     * Post Method
     *
     * @param $request
     * @return WP_REST_Response
     */
    public function reset($request)
    {
        $json_params = $request->get_json_params();
        $email = $json_params['email'];

        $user_exist = get_user_by('email', $email);
        if (!$user_exist) {
            return new WP_REST_Response(array('error' => 'User does not exist'), 400);
        }

        $rand_password = substr(md5(microtime()), rand(0, 26), 6);

        reset_password($user_exist, $rand_password);

        wp_mail($email, 'Password Reset', 'Your Password has been reset. This is randomly generated password : ' . $rand_password);

        return new WP_REST_Response('Password Updated Check your email', 200);

    }


    /**
     * Get single user info by ID
     *
     * @param WP_REST_Request $request
     * @return WP_Error|WP_REST_Response
     */
    public function get_item($request)
    {
        $user_id = $request->get_param('id');
        $url = "https://api.infusionsoft.com/crm/rest/v1/contacts/" . $user_id.'?optional_properties=custom_fields';
        
        global $GLOBALS;
        $countries = $GLOBALS['countries'];

        $access_token = $this->get_keap_token();

        $response = $this->get_data_by_id($url, $access_token);

        $user_data = json_decode($response['body'], true);

        $email = $this->get_primary_email($user_data['email_addresses']);


        $local_user_id = email_exists($email);

        if(!$local_user_id) {
            return new WP_REST_Response(array(
                'error' => 'User id not found'
            ), 400);
        }

        $user_avatar = get_user_meta($local_user_id, 'user_avatar')[0];

        if ($user_avatar) {
            $user_data['user_avatar'] = $user_avatar;
        }
        
        
        // $responseData = json_decode($created_user['body'], true);
        $response_country_code = $user_data['addresses'][0]['country_code'];

        $modified_country_code = array_search($response_country_code, $countries);

        $user_data['addresses'][0]['country_code'] = $modified_country_code;
        

        return new WP_REST_Response(array('user_data' => $user_data), 200);
    }

    /**
     * Get all Users
     *
     * @param WP_REST_Request $request
     * @return WP_Error|WP_REST_Response
     */
    public function get_items($request)
    {
        $email = $request['email'];
        $first_name = $request['firstName'];
        $given_name = $request['lastName'];

        $access_token = $this->get_keap_token();

        $users;
        $contacts_url;
        $query_string_args = array();

        if (!empty($email)) {
            $query_string_args['email'] = $email;
        }
        if (!empty($first_name)) {
            $query_string_args['first_name'] = $first_name;
        }
        if (!empty($given_name)) {
            $query_string_args['given_name'] = $given_name;
        }

        $contacts_url = add_query_arg(
            $query_string_args, 'https://api.infusionsoft.com/crm/rest/v1/contacts'
        );

        $contacts_response = wp_remote_get(
            $contacts_url,
            array(
                'headers' => array(
                    'Accept' => 'application/json, */*',
                    'Authorization' => 'Bearer ' . $access_token
                )
            )
        );

        //add error check for get

        $contacts_body = (array)json_decode($contacts_response['body']);
        $contacts = $contacts_body['contacts'];

        $first_user;
        if (count($contacts) > 0) {
            $first_user = (array)$contacts[0];
        } else {
            return new WP_REST_Response(array(
                'message' => 'User does not exists',
                'error' => 'Resource not found',
                'status' => '404'
            ), 409);
        }

        $get_contact_url = 'https://api.infusionsoft.com/crm/rest/v1/contacts/' . $first_user['id'];

        $contact_response = wp_remote_get(
            $get_contact_url,
            array(
                'headers' => array(
                    'Accept' => 'application/json, */*',
                    'Authorization' => 'Bearer ' . $access_token
                )
            )
        );

        $user = (array)json_decode($contact_response['body']);

        $user_tag_ids = $user['tag_ids'];

        $tags_url = 'https://api.infusionsoft.com/crm/rest/v1/tags/';
        $mobile_created_tag_name = 'Mobile Created'; // tag name used in keap
        $normal_account_tag_name = 'Normal Account'; // tag name used in keap

        $tags = wp_remote_get(
            $tags_url,
            array(
                'headers' => array(
                    'Accept' => 'application/json, */*',
                    'Authorization' => 'Bearer ' . $access_token
                )
            )
        );

        $body_arr = json_decode($tags['body'], true);
        $tags_arr = $body_arr['tags'];
        $user_tags = array();

        $type;
        foreach ($tags_arr as $tag) {
            $tag_arr = (array)$tag;
            $type = gettype($tag_arr);
            if (in_array($tag_arr['id'], $user_tag_ids)) {
                array_push($user_tags, $tag);
            }
        }

        $first_user['tags'] = $user_tags;

        return new WP_REST_Response(
            array(
                'user' => $first_user
            )
            , 200);
    }

    /**
     * Create a new user
     *
     * @param WP_REST_Request $request
     * @return WP_Error|WP_REST_Response
     */
    public function create_item($request)
    {
        $json_params = $request->get_json_params();
        $email = $json_params['email'];
        $first_name = $json_params['firstName'];
        $last_name = $json_params['lastName'];
        $country_code_params = $json_params['country'];
        $password = $json_params['password'];
        $phone = $json_params['phone'];
        $extension = $json_params['extension'];
        $registered_from = $json_params['registeredFrom'];
        $caps_flag_code = strtoupper($country_code_params);
        
        $isPasswordValid = preg_match('/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$/u', $password);
        
        if(!$isPasswordValid) {
            return new WP_REST_Response(array(
                'error' => 'Password must be 8 chars long and must contain lowercase, uppercase, number and spacial char.'    
            ), 401);
        }
        
        
        global $GLOBALS;
        $countries = $GLOBALS['countries'];
        $country_code = $countries[strtoupper($country_code_params)];


        $user_exists = email_exists($email);


        if ($user_exists) {
            return new WP_REST_Response(array(
                'message' => 'User already exists',
                'error' => 'Duplicate Resource',
                'status' => '409'
            ), 409);
        }

        $access_token = $this->get_keap_token();

        // if no access token, return error

        $tags_url = 'https://api.infusionsoft.com/crm/rest/v1/tags/';
        $contacts_url = 'https://api.infusionsoft.com/crm/rest/v1/contacts/?optional_properties=custom_fields';

        $tags = wp_remote_get(
            $tags_url,
            array(
                'headers' => array(
                    'Accept' => 'application/json, */*',
                    'Authorization' => 'Bearer ' . $access_token
                )
            )
        );

        $body_arr = json_decode($tags['body'], true);
        $tags_arr = $body_arr['tags'];
        
        if($registered_from){
            $free_content_tag_name = 'Free Content'; // tag name used in keap
            $free_content_tag_id;
        }else{
            $mobile_created_tag_name = 'Mobile Created'; // tag name used in keap
            $mobile_created_tag_id;    
        }
        // $mobile_created_tag_name = 'Mobile Created'; // tag name used in keap
        // $mobile_created_tag_id;
        $normal_account_tag_name = 'Normal Account'; // tag name used in keap
        $normal_account_tag_id;

        // clean this
        foreach ($tags_arr as $tag) {
            if ($tag['name'] === $free_content_tag_name) {
                $free_content_tag_id = $tag['id'];
            }
            if ($tag['name'] === $normal_account_tag_name) {
                $normal_account_tag_id = $tag['id'];
            }
            if ($tag['name'] === $mobile_created_tag_name) {
                $mobile_created_tag_id = $tag['id'];
            }
        }


        $user_data_wp = array(
            'user_login' => $email,
            'user_email' => $email,
            'first_name' => $first_name,
            'last_name' => $last_name,
            'user_pass' => $password,
            'send_email' => false
        );

        $result = wp_insert_user($user_data_wp);

        $responseData;
        $responseCode = 200;

        if (!is_wp_error($result)) {

            $user_data = array(
                'email_addresses' => array(
                    array(
                        'email' => $email,
                        'field' => 'EMAIL1'
                    )
                ),
                'addresses' => array(
                    array(
                        'country_code' => $country_code,
                        'field' => 'BILLING'
                    )
                ),
                // "_DialCode" => $extension,
                'custom_fields' => array(
                    array(
                          'content' => $extension,
                          'id' => 15,
                    ),
                    array(
                          'content' => $caps_flag_code,
                          'id' => 17,
                    ),
                ),
                'duplicate_option' => 'Email',
                'email_opted_in' => true,
                'given_name' => $first_name,
                'family_name' => $last_name,
                'phone_numbers' => array(
                    array(
                        'extension' => "",
                        'number' => $phone,
                        'field' => 'PHONE1',
                        'type' => 'Other'
                    )
                )
            );

            $created_user = wp_remote_post(
                $contacts_url,
                array(
                    'method' => 'PUT',
                    'headers' => array(
                        'Accept' => 'application/json, */*',
                        'Authorization' => 'Bearer ' . $access_token,
                        'Content-Type' => 'application/json; charset=UTF-8'
                    ),
                    'body' => json_encode($user_data)
                )
            );

            $created_user_arr = json_decode($created_user['body'], true);
            $created_user_id = $created_user_arr['id'];

            $apply_tag_url = "https://api.infusionsoft.com/crm/rest/v1/contacts/" . $created_user_id . '/tags';

            $updated_user = wp_remote_post(
                $apply_tag_url,
                array(
                    'headers' => array(
                        'Accept' => 'application/json, */*',
                        'Authorization' => 'Bearer ' . $access_token,
                        'Content-Type' => 'application/json; charset=UTF-8'
                    ),
                    'body' => json_encode(
                        array(
                            'tagIds' => array($normal_account_tag_id, $mobile_created_tag_id, $free_content_tag_id)
                        )
                    )
                )
            );

            $responseData = json_decode($created_user['body'], true);
        
            $response_country_code = $responseData['addresses'][0]['country_code'];

            $modified_country_code = array_search($response_country_code, $countries);

            $responseData['addresses'][0]['country_code'] = $modified_country_code;

        } else {
            $responseData = array(
                'error' => $result
            );
            $responseCode = 500;
        }


        return new WP_REST_Response($responseData, $responseCode);
    }

/**
     * add Free Cotent tag
     *
     * @param WP_REST_Request $request
     * @return WP_Error|WP_REST_Response
     */
    public function update_free_content_tags($request){
        $access_token = $this->get_keap_token();

        $user_id = (int)$request->get_param('id');

        // if no access token, return error

        $tags_url = 'https://api.infusionsoft.com/crm/rest/v1/tags/';

        $tags = wp_remote_get(
            $tags_url,
            array(
                'headers' => array(
                    'Accept' => 'application/json, */*',
                    'Authorization' => 'Bearer ' . $access_token
                )
            )
        );
        $body_arr = json_decode($tags['body'], true);
        $tags_arr = $body_arr['tags'];

        $free_content_tag_id;

        foreach ($tags_arr as $tag) {
            if ($tag['name'] === 'Free Content') {
                $free_content_tag_id = $tag['id'];
            }
        }

        $apply_tag_url = "https://api.infusionsoft.com/crm/rest/v1/contacts/" . $user_id . '/tags';

        $updated_user = wp_remote_post(
            $apply_tag_url,
            array(
                'headers' => array(
                    'Accept' => 'application/json, */*',
                    'Authorization' => 'Bearer ' . $access_token,
                    'Content-Type' => 'application/json; charset=UTF-8'
                ),
                'body' => json_encode(
                    array(
                        'tagIds' => array($free_content_tag_id)
                    )
                )
            )
        );

        if($updated_user['response']['code'] !== 200){
            return new WP_REST_Response(array(
                'error'=>'Unable to apply tag'
            ),$updated_user['response']['code']);
        }

        $responseData = json_decode($updated_user['body']);

        return new WP_REST_Response($responseData, 200);
    }

    /**
     * Update User Profile
     *
     * @param WP_REST_Request $request
     * @return WP_Error|WP_REST_Response
     */
    public function update_item($request)
    {
        $json_params = $request->get_json_params();
        $id = $request->get_param('id');
        $first_name = $json_params['firstName'];
        $last_name = $json_params['lastName'];
        $email = $json_params['email'];
        $street_address = $json_params['streetAddress'];
        $phone = $json_params['phone'];
        $city = $json_params['city'];
        $state = $json_params['state'];
        $postal = $json_params['postal'];
        $country_code_params = $json_params['country'];
        $password = $json_params['password'];
        $extension = $json_params['extension'];
        $caps_flag_code = strtoupper($country_code_params);

        //  Check if auth header is present
        if (empty($request->get_header('authorization'))) {
            return new WP_REST_Response(array(
                'error' => 'Unauthorized User'
            ), 400);
        }
        
        $isPasswordValid = preg_match('/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$/u', $password);
        
        if(!$isPasswordValid  && !empty($password)) {
            return new WP_REST_Response(array(
                'error' => 'Password must be 8 chars long and must contain lowercase, uppercase, number and spacial char.'    
            ), 401);
        }
        
        
        global $GLOBALS;
        $countries = $GLOBALS['countries'];
        $country_code = $countries[strtoupper($country_code_params)];

        $contacts_url = 'https://api.infusionsoft.com/crm/rest/v1/contacts/' . $id.'?optional_properties=custom_fields';

        $access_token = $this->get_keap_token();
        $response = $this->get_data_by_id($contacts_url, $access_token);

        $body = json_decode($response['body'], true);
        $updated_first_name = $this->merge_user_data($first_name, $body['given_name']);
        $updated_last_name = $this->merge_user_data($last_name, $body['family_name']);
        $updated_phone = $this->merge_user_data($phone, $body['phone_numbers'][0]['number']);
        $updated_street_address = $this->merge_user_data($street_address, $body['addresses'][0]['line1']);
        $updated_city = $this->merge_user_data($city, $body['addresses'][0]['locality']);
        $updated_state = $this->merge_user_data($state, $body['addresses'][0]['region']);
        $updated_zip = $this->merge_user_data($postal, $body['addresses'][0]['postal_code']);
        $updated_country = $this->merge_user_data($country_code, $body['addresses'][0]['country_code']);
        
        
        $updated_extension;
        $updated_flagcode;
       
        
        foreach($body['custom_fields'] as $custom_field) {
        
            
            if($custom_field['id'] == 15) {
                $updated_extension = $this->merge_user_data($extension, $custom_field['content']);        
            }
            
             if($custom_field['id'] == 17) {
                $updated_flagcode = $this->merge_user_data($caps_flag_code, $custom_field['content']);        
            }
        }
        


        $email_addresses = $body['email_addresses'];
        $existing_first_name = $body['given_name'];
        $existing_last_name = $body['family_name'];
        $existing_email = $this->get_primary_email($email_addresses);

        $user_exists = email_exists($existing_email);

        if (!$user_exists) {
            return new WP_REST_Response(array(
                'error' => 'User Not Found'
            ), 400);
        }

        // password update
        if (!empty($password)) {
            wp_set_password($password, $user_exists);
        }

        $updated_email = $this->merge_user_data($email, $existing_email);

        // Update new user data in Wordpress Database
        $user_data = wp_update_user(array('ID' => $user_exists, 'first_name' => $first_name, 'last_name' => $last_name, 'user_email' => $updated_email));


        if (is_wp_error($user_data)) {
            return new WP_REST_Response(array(
                'error' => 'User Could not be updated'
            ), 500);
        }// END Password update


        $user_data = array(
            'email_addresses' => array(
                array(
                    'email' => $updated_email,
                    'field' => 'EMAIL1'
                )
            ),
            "addresses" => array(
                array(
                    'country_code' => $updated_country,
                    'line1' => $updated_street_address,
                    "line2" => "",
                    "locality" => $updated_city,
                    "postal_code" => $updated_zip,
                    "region" => $updated_state,
                    "zip_code" => $updated_zip,
                    "field" => "BILLING",
                    "zip_four" => ""
                )
            ),
            'custom_fields' => array(
                array(
                    'content' => $updated_extension,
                    'id' => 15,
                ),
                array(
                    'content' => $updated_flagcode,
                    'id' => 17,
                ),
            ),
            "phone_numbers" => array(
                array(
                    "extension" => "",
                    "field" => "PHONE1",
                    "number" => $updated_phone,
                    "type" => "Other"
                )
            ),
            'given_name' => $updated_first_name,
            'family_name' => $updated_last_name,

        );
        //return new WP_REST_Response($user_data, 200);

        $updated_user = wp_remote_post(
            $contacts_url,
            array(
                'method' => 'PATCH',
                'headers' => array(
                    'Accept' => 'application/json, */*',
                    'Authorization' => 'Bearer ' . $access_token,
                    'Content-Type' => 'application/json; charset=UTF-8'
                ),
                'body' => json_encode($user_data)
            )
        );

        $responseData = json_decode($updated_user['body'], true);
        $response_country_code = $responseData['addresses'][0]['country_code'];
        
        $modified_country_code = array_search($response_country_code, $countries);
        $responseData['addresses'][0]['country_code'] = $modified_country_code;
        $response_code = $updated_user['response']['code'];

        if ($response_code != 200) {
            // Reverting local database if keap update fail
            wp_update_user(array('ID' => $user_exists, 'first_name' => $existing_first_name, 'last_name' => $existing_last_name, 'user_email' => $existing_email));
            return new WP_REST_Response(array(
                'error' => $updated_user['response']
            ), 400);
        }

        return new WP_REST_Response($responseData, 200);

    }


    /**
     * Get all tags associated to user
     *
     * @param $request
     * @return WP_REST_Response
     */
    public function get_tags($request)
    {
        $user_id = $request->get_param('id');
        $url = "https://api.infusionsoft.com/crm/rest/v1/contacts/" . $user_id . "/tags";

        $access_token = $this->get_keap_token();

        $response = $this->get_data_by_id($url, $access_token);

        $body = json_decode($response['body'], true);

        return new WP_REST_Response($body['tags'], 200);

    }


    /**
     * Upload Avatar
     *
     * @param WP_REST_Request $request
     * @return bool|void|WP_Error
     */
    public function upload_avatar($request)
    {
//        $files = $request->get_file_params();
        $id = $request->get_param('id');
        $image_b64 = $request->get_json_params()['image'];

        // Auth will be placed here
        if (empty($request->get_header('authorization'))) {
            return new WP_REST_Response(array(
                'error' => 'Unauthorized User'
            ), 400);
        }

        $contacts_url = 'https://api.infusionsoft.com/crm/rest/v1/contacts/' . $id;

        $access_token = $this->get_keap_token();
        $response = $this->get_data_by_id($contacts_url, $access_token);

        $body = json_decode($response['body'], true);

        $email_addresses = $body['email_addresses'];
        $existing_email;

        foreach ($email_addresses as $email_single) {
            if ($email_single['field'] == 'EMAIL1') {
                $existing_email = $email_single['email'];
            }
        }

        $user_id = email_exists($existing_email);

        if (!$user_id) {
            return new WP_REST_Response(array('error' => 'User not found'), 200);
        }

        try {

            $fixed = $user_id . '-';
            $number = $fixed . mt_rand(10000000, 99999999);
            $image = base64_decode($image_b64);

            $upload_path = wp_upload_dir()['basedir'] . '/avatars/' . $user_id . '/' . $number . '-avatar.jpg';
            $upload_thumb_path = wp_upload_dir()['basedir'] . '/avatars/' . $user_id . '/' . $number . '-avatar-thumb.jpg';
            $upload_url = wp_upload_dir()['baseurl'] . '/avatars/' . $user_id . '/' . $number . '-avatar.jpg';
            $upload_thumb_url = wp_upload_dir()['baseurl'] . '/avatars/' . $user_id . '/' . $number . '-avatar-thumb.jpg';

            // Check if user directory exists
            // If not create it
            if (!is_dir(wp_upload_dir()['basedir'] . '/avatars/' . $user_id)) {
                mkdir(wp_upload_dir()['basedir'] . '/avatars/' . $user_id, 0777, true);
            }


            $result = file_put_contents($upload_path, $image);

            if (!$result) {
                throw new Exception("Unable to save image", 500);
            }

            $image_editor = wp_get_image_editor($upload_path);

            if (is_wp_error($image_editor)) {
                throw new Exception("Unable to load image", 500);
            }

            $image_editor->resize(90, 90);
            $image_editor->save($upload_thumb_path);
            $meta_id = update_user_meta($user_id, 'user_avatar', array('url' => $upload_url, 'thumb' => $upload_thumb_url));
            if (!$meta_id) {
                throw new Exception("Unable to save image", 500);
            }
            $user_avatar = get_user_meta($user_id, 'user_avatar');
            return new WP_REST_Response($user_avatar[0], 200);

        } catch (Exception $exception) {
            return new WP_REST_Response(array('error' => $exception->getMessage()), $exception->getCode());
        }


    }

    public function remove_avatar($request)
    {
        $id = $request->get_param('id');

        $contacts_url = 'https://api.infusionsoft.com/crm/rest/v1/contacts/' . $id;

        $access_token = $this->get_keap_token();
        $response = $this->get_data_by_id($contacts_url, $access_token);

        $body = json_decode($response['body'], true);

        $email_addresses = $body['email_addresses'];
        $existing_email;

        foreach ($email_addresses as $email_single) {
            if ($email_single['field'] == 'EMAIL1') {
                $existing_email = $email_single['email'];
            }
        }

        $user_id = email_exists($existing_email);

        $remove_meta_id = delete_user_meta($user_id, 'user_avatar');

        if ($remove_meta_id) {
            return new WP_REST_Response(array(
                'message' => 'User profile photo deleted'
            ), 200);
        }

        return new WP_REST_Response(array(
            'error' => 'No avatar found'
        ), 400);

    }


    /**
     * List of Orders
     * Orders Fetch by user keap Id
     *
     * @param WP_REST_Request $request
     * @return bool|void|WP_Error
     */
    public function get_billing_detail($request)
    {

        $user_id = $request->get_param('id');

//      orders?contact_id=367
//        Get Orders
        $url = "https://api.infusionsoft.com/crm/rest/v1/orders?contact_id=" . $user_id;

        $access_token = $this->get_keap_token();

        $response = $this->get_data_by_id($url, $access_token);
        $body = json_decode($response['body'], true);


//        return new WP_REST_Response($body, 200);

        $orders = $body['orders'];

        //        Get Subsrciption
        $subscriptions_url = "https://api.infusionsoft.com/crm/rest/v1/subscriptions?contact_id=" . $user_id;

        $response = $this->get_data_by_id($subscriptions_url, $access_token);
        $subscriptions_data = json_decode($response['body'], true);


        $invoices = [];


        foreach ($orders as $order) {
            $order_subscription;
            foreach ($subscriptions_data['subscriptions'] as $subscription) {
                if ($subscription['id'] == $order['order_items'][0]['jobRecurringId']) {
                    $order_subscription = $subscription;
                }
            }
            $updated_order = array(
                'id' => $order['id'],
                'title' => $order['title'],
                'total' => $order['total'],
                'order_date' => $order['order_date'],
                'total_paid' => $order['total_paid'],
                'total_due' => $order['total'] - $order['total_paid'],
                'order_name' => $order['order_items'][0]['name'],
                'subscription' => $order_subscription
            );
            
            if($order_subscription !== null){
                $invoices[] = $updated_order;
            }
            
        }

        if(empty($invoices)){
            return new WP_REST_Response(array(
                'message'=>'No Subscriptions Found'
            ), 404);
        }

        return new WP_REST_Response($invoices, 200);
    }

    /**
     * Get order Invoices by Contact Id
     *
     * @param WP_REST_Request $request
     * @return bool|void|WP_Error
     * /contacts/{contactId}/invoices
     *
     */    
    public function get_invoices($request){
        $user_id = $request->get_param('id');


        $url = "https://api.infusionsoft.com/crm/rest/v1/orders?contact_id=" . $user_id;

        $access_token = $this->get_keap_token();

        $response = $this->get_data_by_id($url, $access_token);
        $body = json_decode($response['body'], true);

        $orders = $body['orders'];
        
         $invoices = [];

        foreach ($orders as $order) {
            $updated_order = array(
                'id' => $order['id'],
                'title' => $order['title'],
                'total' => $order['total'],
                'order_date' => $order['order_date'],
                'total_paid' => $order['total_paid'],
                'total_due' => $order['total'] - $order['total_paid'],
                'order_name' => $order['order_items'][0]['name'],
            );
                $invoices[] = $updated_order;
                
        }

        return new WP_REST_Response($invoices);
    }


    /**
     * Get Credit Card details by Contact Id
     *
     * @param WP_REST_Request $request
     * @return bool|void|WP_Error
     * /contacts/{contactId}/creditCards
     *
     */
    public function get_creditcard_detail($request)
    {
        $user_id = $request->get_param('id');

        $url = "https://api.infusionsoft.com/crm/rest/v1/contacts/" . $user_id . "/creditCards";

        $access_token = $this->get_keap_token();

        $response = $this->get_data_by_id($url, $access_token);

        $body = json_decode($response['body'], true);

        return new WP_REST_Response(array('creditCards' => $body), 200);
    }


}
