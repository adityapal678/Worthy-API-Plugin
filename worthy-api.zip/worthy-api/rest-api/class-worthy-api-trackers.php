<?php

class Worthy_Trackers_Route extends WP_REST_Controller
{

    public function register_routes()
    {
        $version = '1';
        $namespace = 'worthy/v' . $version;
        $base = 'trackers';
        register_rest_route($namespace, '/users/(?P<id>[\d]+)/' . $base, array(
            array(
                'methods' => WP_REST_Server::EDITABLE,
                'callback' => array($this, 'update_item'),
                'permission_callback' => '__return_true'
            )
        ));

        register_rest_route($namespace, '/users/(?P<id>[\d]+)/' . $base . '/today', array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array($this, 'get_today_tracker'),
                'permission_callback' => '__return_true'
            ),
        ));

//        register_rest_route($namespace, '/users/(?P<id>[\d]+)/' . $base, array(
//            array(
//                'methods' => WP_REST_Server::READABLE,
//                'callback' => array($this, 'get_statistics'),
//                'permission_callback' => '__return_true'
//            ),
//        ));

//      Get All statistics at once running
        register_rest_route($namespace, '/users/(?P<id>[\d]+)/' . $base, array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array($this, 'get_statistics'),
                'permission_callback' => '__return_true'
            ),
        ));
        
        register_rest_route($namespace, '/events', array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array($this, 'get_events'),
                'permission_callback' => '__return_true'
            ),
        ));
    }

    // getting Keap access token from local db
    public function get_keap_token()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . "worthy_oauth_client_credentials";
        $sql = "
      SELECT * FROM $table_name WHERE client_name='keap'
    ";
        $keap_details = $wpdb->get_results($sql);
        $first = (array)$keap_details[0];
        $access_token = null;

        if (!empty($first)) {
            $access_token = $first['access_token'];
        }
        return $access_token;
    }

    // get user authorized by keap access token
    public function get_data_by_id($url, $keap_access_token)
    {
        $response = wp_remote_get(
            $url,
            array(
                'headers' => array(
                    'Accept' => 'application/json, */*',
                    'Authorization' => 'Bearer ' . $keap_access_token
                )
            )
        );
        return $response;
    }

    // get WP user id with use of KEAP ID
    public function get_wp_userid($keap_user_id)
    {
        $contacts_url = 'https://api.infusionsoft.com/crm/rest/v1/contacts/' . $keap_user_id;

        $access_token = $this->get_keap_token();
        $response = $this->get_data_by_id($contacts_url, $access_token);

        $body = json_decode($response['body'], true);

        $email_addresses = $body['email_addresses'];
        $existing_email;


        foreach ($email_addresses as $email_single) {
            if ($email_single['field'] == 'EMAIL1') {
                $existing_email = $email_single['email'];
            }
        }

        $user_id = email_exists($existing_email);

        if (!$user_id) {
            return new WP_REST_Response(array(
                'error' => 'User Not Found'
            ), 400);
        }

        return $user_id;
    }

    public function return_periodically_data($interval, $user_id)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . "worthy_daily_tracker";

        $get_tracker = $wpdb->get_results("SELECT `hydrate`,`mindfulness`,`movement`,`self_care`,`gratitude`,`journal`
        FROM `" . $table_name . "` WHERE DATE(`created`) BETWEEN DATE_SUB(NOW(), INTERVAL " . $interval . " DAY) AND NOW()
        AND `user_id`=$user_id");


        return $get_tracker;
    }

//    -------------------------------------------------

    /**
     * INSERT Tracker data per day
     * UPDATE if day tracker exists
     *
     * @param WP_REST_Request $request
     * @return WP_Error|WP_REST_Response
     */
    public function update_item($request)
    {

        global $wpdb;
        $json_params = $request->get_json_params();
        $keap_user_id = (int)$request->get_param('id');
        $table_name = $wpdb->prefix . "worthy_daily_tracker";

        //  Check if auth header is present
        if (empty($request->get_header('authorization'))) {
            return new WP_REST_Response(array(
                'error' => 'Unauthorized User'
            ), 400);
        }

        $user_id = $this->get_wp_userid($keap_user_id);

        $data = array(
            'user_id' => $user_id,
            'hydrate' => boolval($json_params['hydrate']),
            'mindfulness' => boolval($json_params['mindfulness']),
            'movement' => boolval($json_params['movement']),
            'self_care' => boolval($json_params['selfcare']),
            'gratitude' => boolval($json_params['gratitude']),
            'journal' => boolval($json_params['journal']),
        );

        $update_query = $wpdb->prepare("UPDATE `" . $table_name . "`
            SET `hydrate`=%d,`mindfulness`=%d,`movement`=%d,`self_care`=%d,
            `gratitude`=%d,`journal`=%d WHERE DATE(`created`) = CURDATE() AND `user_id`=%d",
            array($data['hydrate'], $data['mindfulness'], $data['movement'], $data['self_care'], $data['gratitude'], $data['journal'], $user_id));

        $executed_update_query = $wpdb->query($update_query);

        // Data updated successful
        if ($executed_update_query !== 0) {
            return new WP_REST_Response(array(
                'message' => 'Tracker Data Updated'
            ), 200);
        }

        $get_today_tracker = $wpdb->get_results("SELECT * FROM `" . $table_name . "` WHERE DATE(`created`) = CURDATE() AND `user_id`=" . $user_id);
        // Data is already up to date
        if (count($get_today_tracker) > 0) {
            return new WP_REST_Response(array(
                'message' => 'Tracker Data is up to date'
            ), 200);
        }

        // New Data insert query
        $insert_new_data = $wpdb->insert($table_name, $data);
        if (!$insert_new_data) {
            return new WP_REST_Response(array(
                'error' => 'Tracker Data creation failed'
            ), 400);
        }

        return new WP_REST_Response(array(
            'message' => 'New Tracker Data Added'
        ), 200);

    }


//    -------------------------------------------------

    /**
     * GET statistics
     * All period statistics at a single run
     *
     * @param $request
     * @return WP_REST_Response
     */
    public function get_statistics($request)
    {
 $keap_user_id = $request->get_param('id');
        $user_id = $this->get_wp_userid($keap_user_id);

        $current_time = strtotime("now");
        $week_old_time = strtotime("-7 days");
        $month_old_time = strtotime("-1 month");
        $quarter_old_time = strtotime("-3 month");
        $semi_anual_old_time = strtotime("-6 month");
        $anual_old_time = strtotime("-1 year");
        $days_in_year = round(($current_time - $anual_old_time) / (60 * 60 * 24));


        $yearly_tracker_data = $this->return_periodically_data($days_in_year, $user_id);

        $tracker_data = [];

        foreach ($yearly_tracker_data as $key => $tracker) {
            $date = date_format(date_create($tracker->created), 'Y-m-d');
            $tracker_data[$key]['hydrate'] = (int)$tracker->hydrate;
            $tracker_data[$key]['mindfulness'] = (int)$tracker->mindfulness;
            $tracker_data[$key]['movement'] = (int)$tracker->movement;
            $tracker_data[$key]['self_care'] = (int)$tracker->self_care;
            $tracker_data[$key]['gratitude'] = (int)$tracker->gratitude;
            $tracker_data[$key]['journal'] = (int)$tracker->journal;
            $tracker_data[$key]['date'] = strtotime($date);
            $tracker_data[$key]['month'] = (int)date('m', strtotime($date)) ;
            $tracker_data[$key]['day'] = (int)date('d', strtotime($date)) ;
            $tracker_data[$key]['year'] = (int)date('Y', strtotime($date)) ;
            $tracker_data[$key]['days_in_month'] = cal_days_in_month(CAL_GREGORIAN,(int)date('m', strtotime($date)),(int)date('Y', strtotime($date)));
        }

        $tracker_array = array(
            'week' => [],
            'month'=> [],
            'quartor' => [],
            'semi_anual'=> [],
            'anual'=>[]
        );




        // Month
        foreach ($tracker_data as $tracker) {
            if($tracker['date'] > $week_old_time && $tracker['date'] < $current_time) {
                $tracker_array['week']['hydrate'] += $tracker['hydrate'];
                $tracker_array['week']['mindfulness'] += $tracker['mindfulness'];
                $tracker_array['week']['movement'] += $tracker['movement'];
                $tracker_array['week']['self_care'] += $tracker['self_care'];
                $tracker_array['week']['gratitude'] += $tracker['gratitude'];
                $tracker_array['week']['journal'] += $tracker['journal'];
                $tracker_array['week']['total_days'] = round(($current_time - $week_old_time) / (60 * 60 * 24));
            }

            if($tracker['date'] > $month_old_time && $tracker['date'] < $current_time) {
                $tracker_array['month']['hydrate'] += $tracker['hydrate'];
                $tracker_array['month']['mindfulness'] += $tracker['mindfulness'];
                $tracker_array['month']['movement'] += $tracker['movement'];
                $tracker_array['month']['self_care'] += $tracker['self_care'];
                $tracker_array['month']['gratitude'] += $tracker['gratitude'];
                $tracker_array['month']['journal'] += $tracker['journal'];
                $tracker_array['month']['total_days'] = round(($current_time - $month_old_time) / (60 * 60 * 24));
            }

            if($tracker['date'] > $quarter_old_time && $tracker['date'] < $current_time) {
                $tracker_array['quartor']['hydrate'] += $tracker['hydrate'];
                $tracker_array['quartor']['mindfulness'] += $tracker['mindfulness'];
                $tracker_array['quartor']['movement'] += $tracker['movement'];
                $tracker_array['quartor']['self_care'] += $tracker['self_care'];
                $tracker_array['quartor']['gratitude'] += $tracker['gratitude'];
                $tracker_array['quartor']['journal'] += $tracker['journal'];
                $tracker_array['quartor']['total_days'] = round(($current_time - $quarter_old_time) / (60 * 60 * 24));
            }

            if($tracker['date'] > $semi_anual_old_time && $tracker['date'] < $current_time) {
                $tracker_array['semi_anual']['hydrate'] += $tracker['hydrate'];
                $tracker_array['semi_anual']['mindfulness'] += $tracker['mindfulness'];
                $tracker_array['semi_anual']['movement'] += $tracker['movement'];
                $tracker_array['semi_anual']['self_care'] += $tracker['self_care'];
                $tracker_array['semi_anual']['gratitude'] += $tracker['gratitude'];
                $tracker_array['semi_anual']['journal'] += $tracker['journal'];
                $tracker_array['semi_anual']['total_days'] = round(($current_time - $semi_anual_old_time) / (60 * 60 * 24));
            }

            if($tracker['date'] > $anual_old_time && $tracker['date'] < $current_time) {
                $tracker_array['anual']['hydrate'] += $tracker['hydrate'];
                $tracker_array['anual']['mindfulness'] += $tracker['mindfulness'];
                $tracker_array['anual']['movement'] += $tracker['movement'];
                $tracker_array['anual']['self_care'] += $tracker['self_care'];
                $tracker_array['anual']['gratitude'] += $tracker['gratitude'];
                $tracker_array['anual']['journal'] += $tracker['journal'];
                $tracker_array['anual']['total_days'] = round(($current_time - $anual_old_time) / (60 * 60 * 24));
            }

        }


        return new WP_REST_Response($tracker_array, 200);

    }
    
    
    public function get_events($request)
    {

        $unix_current_time = strtotime("now");
        $start_date = date('Y-m-d H:i:s', $unix_current_time);
        $last_day_of_month = date("Y-m-t", $unix_current_time);
        $first_day_of_next_month = (int)date_format(date_create($last_day_of_month), 'U') + (60 * 60 * 24);

        $events = tribe_get_events(array(
            'start_date' => $start_date
        ), false);

        $current_month_events = [];

        foreach($events as $event) {
            if( strtotime($event->event_date) < $first_day_of_next_month) {
                $current_month_events[] = $event;
            }
        }

        return new WP_REST_Response($current_month_events, 200);
    }

//    -------------------------------------------------

    /**
     * GET trakder data by ID
     * GET today tracker DATA
     *
     * @param $request
     * @return WP_REST_Response
     */
    public function get_today_tracker($request)
    {
        global $wpdb;
        $query_params = $request->get_query_params();
        $keap_user_id = $request->get_param('id');
        $table_name = $wpdb->prefix . "worthy_daily_tracker";

//      Keap Id existed we need to get WP user Id
        $user_id = $this->get_wp_userid($keap_user_id);

        if (!is_int($user_id)) {
            return new WP_REST_Response(array(
                'error' => 'User Not Found'
            ), 400);
        }

        //    Get stastistics of given period  Result
        $get_today_tracker = $wpdb->get_results("SELECT `hydrate`,`mindfulness`,`movement`,`self_care`,`gratitude`,`journal`
        FROM `" . $table_name . "` WHERE DATE(`created`) = CURDATE() AND `user_id`=$user_id");

        if (empty($get_today_tracker)) {
            return new WP_REST_Response(array(
                'error' => 'No Today Data Available'
            ), 400);
        }

        $sorted_data = array(
            'hydrate' => (int)$get_today_tracker[0]->hydrate,
            'mindfulness' => (int)$get_today_tracker[0]->mindfulness,
            'movement' => (int)$get_today_tracker[0]->movement,
            'self_care' => (int)$get_today_tracker[0]->self_care,
            'gratitude' => (int)$get_today_tracker[0]->gratitude,
            'journal' => (int)$get_today_tracker[0]->journal,
        );

        return new WP_REST_Response($sorted_data);

    }
    
    

}
