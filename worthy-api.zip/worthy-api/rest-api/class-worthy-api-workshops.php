<?php

class Worthy_Workshops_Route extends WP_REST_Controller {

  public function register_routes() {
    $version = '1';
    $namespace = 'worthy/v' . $version;
    $base = 'workshops';
  
    register_rest_route( $namespace, '/' . $base . '/courses', array(
      array(//workshops enrolled for
        'methods' => WP_REST_Server::READABLE,
        'callback' => array ( $this, 'get_courses' ),
        'permission_callback' => '__return_true'
      )
    ) );
    register_rest_route( $namespace, '/' . $base, array(
      array(//workshops enrolled for
        'methods' => WP_REST_Server::READABLE,
        'callback' => array ( $this, 'get_items' ),
        'permission_callback' => '__return_true'
      )
    ) );
    register_rest_route( $namespace, '/users/(?P<id>[\d]+)/' . $base, array(
      array(//workshops enrolled for
        'methods' => WP_REST_Server::READABLE,
        'callback' => array ( $this, 'get_user_items' ),
        'permission_callback' => '__return_true'
      ),
      array(
        'methods' => WP_REST_Server::CREATABLE,
        'callback' => array ( $this, 'create_item' ),
        'permission_callback' => '__return_true'
      )
    ) );
    register_rest_route( $namespace, '/users/(?P<user_id>[\d]+)/' . $base . '/(?P<workshop_id>[\d]+)', array(
      array(
        'methods' => WP_REST_Server::READABLE,
        'callback' => array ( $this, 'get_item' ),
        'permission_callback' => '__return_true'
      ),
      array(
        'methods' => WP_REST_Server::EDITABLE,
        'callback' => array ( $this, 'update_item' ),
        'permission_callback' => '__return_true'
      ),
      array(
        'methods' => WP_REST_Server::DELETABLE,
        'callback' => array ( $this, 'delete_item' ),
        'permission_callback' => '__return_true'
      ),
    ) );
  }

  public function count_user_workshops() {
    global $wpdb;
    $table_name = $wpdb->prefix . "users";
    $sql = "
      SELECT COUNT(*) FROM $table_name
    ";
    $count = $wpdb->get_var( $sql );

    return new WP_REST_Response( array('workshopsCount' => $count), 200 );
  }

  public function get_items( $request ) {
    global $wpdb;
    $query_params = $request->get_query_params();
    $category = $query_params['category'];
    return $category;
    $table_name = $wpdb->prefix . "posts";
    $sql = "
      SELECT * FROM $table_name WHERE post_type='sfwd-courses'
    ";

    if (array_key_exists('title', $query_params)) {
      $title = $query_params['title'];
      $sql = $sql . "AND post_title LIKE '%$title%'";
    }

    // category -> term, post -> term_relationships -> term
    // if (array_key_exists('category', $query_params)) {
    //   $category = $query_params['category'];
    //   $sql = $sql . "AND category IN(implode(',', $category)";
    // }

    $trackers = $wpdb->get_results( $sql );

    return new WP_REST_Response( $trackers, 200 );
  }

  public function get_user_items( $request ) {
    global $wpdb;
    $query_params = $request->get_query_params();
    $table_name = $wpdb->prefix . "posts";
    $sql = "
      SELECT * FROM $table_name WHERE post_type='sfwd-courses'
    ";

    if (array_key_exists('title', $query_params)) {// for search query
      $title = $query_params['title'];
      $sql = $sql . "AND WHERE post_title LIKE '%$title%'";
    }

    /* if (array_key_exists('categor. ', $query_params)) {// for courses based on category
      $sql = $sql .;
    } */

    $trackers = $wpdb->get_results( $sql );

    return new WP_REST_Response( $trackers, 200 );
  }

  public function get_item( $request ) {}

  public function create_item( $request ) {
  }

  public function update_item( $request ) {
  }

  public function delete_item( $request ) {}

  // dont need any of these function right now
  public function get_items_permissions_check( $request ) {}
  public function get_item_permissions_check( $request ) {}
  public function create_item_permissions_check( $request ) {}
  public function update_item_permissions_check( $request ) {}
  public function delete_item_permissions_check( $request ) {}

  protected function prepare_item_for_database( $request ) {}
  public function prepare_item_for_response( $item, $request ) {}
  public function get_collection_params() {}
}
