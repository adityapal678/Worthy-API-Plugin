<?php

require_once ( ABSPATH . '/wp-load.php' );
require_once ( ABSPATH . '/wp-admin/includes/user.php' );

class Worthy_Profile_Route extends WP_REST_Controller {

  public function register_routes() {
    $version = '1';
    $namespace = 'worthy/v' . $version;
    $base = 'profile';
    register_rest_route( $namespace, '/' . $base, array(
      'methods' => WP_REST_Server::READABLE,
      'callback' => array ( $this, 'get_items' ),
      'permission_callback' => '__return_true'
    ) );
    register_rest_route( $namespace, '/users/(?P<id>[\d]+)/' . $base . '/update-password', array(
      array(
        'methods' => WP_REST_Server::EDITABLE,
        'callback' => array ( $this, 'update_password' ),
        'permission_callback' => '__return_true'
      )
    ) );
    register_rest_route( $namespace, '/users/(?P<id>[\d]+)/' . $base, array(
      array(
        'methods' => WP_REST_Server::EDITABLE,
        'callback' => array ( $this, 'update_item' ),
        'permission_callback' => '__return_true'
      )
    ) );
  }

  public function get_items( $request ) {
    global $wpdb;
    $user_id = $request->get_param('id');


    // return new WP_REST_Response( array(
    //   'message' => ,
    //   'profile' => array(
    //     'firstName' => ,
    //     'lastName' => ,
    //     'email' => ,
    //     'phone' => ,
    //   )
    //   'status' => 
    // ), 200 );
  }

  public function update_password( $request ) {
    $user_id = $request->get_param('id');
    $json_params = $request->get_json_params();
    $new_password = $json_params['newPassword'];
    $old_password = $json_params['oldPassword'];

    if (empty($new_password)){
      return new WP_REST_Response( array('message'=>'New password is required'), 400 );
    }
    if (empty($old_password)){
      return new WP_REST_Response( array('message'=>'Old password is required'), 400 );
    }

    $user = get_user_by( 'id', $user_id );

    if ( !$user ) {
      return new WP_REST_Response( array('message'=>'User not found.'), 404 );
    }

    $hash = $user->data->user_pass;
    if (wp_check_password( $old_password, $hash ) ){
      wp_set_password( $new_password, $user_id );
    } else {
      return new WP_REST_Response( array('message'=>'Current password does not match.'), 400 );
    }

    return new WP_REST_Response( array('message'=>'Password updated successfuly.'), 200 );
  }

  public function update_item( $request ) {
    global $wpdb;
    $json_params = $request->get_json_params();
    $user_id = $request->get_param('id');
    $buddy_boss_profile_table_name = $wpdb->prefix . 'bp_xprofile_data';

    $first_name = $json_params['firstName'];
    $last_name = $json_params['lastName'];
    $new_email = $json_params['newEmail'];
    $new_phone = $json_params['newPhone'];

    $old_first_name;
    $old_last_name;

    $search_sql = "
      select * from $buddy_boss_profile_table_name where user_id=$user_id
    ";

    $user_details = $wpdb->get_results( $search_sql );

    return new WP_REST_Response( array(
      'raw' => $user_details,
      'details' => json_decode( $user_details['body'], true ),
      'user' => $user_id,
    ), 200);

    // $full_name;

    // if (!empty($first_name)) {
    //   $full_name = 
    //   $updated_buddy_boss_first_name = $wpdb->update( $buddy_boss_profile_table_name, array( 'value' => $first_name ), array( 'field_id' => 1, 'user_id' => $user_id ) );
    // }
    
    // if (!empty($last_name)) {
    //   $updated_buddy_boss_last_name = $wpdb->update( $buddy_boss_profile_table_name, array( 'value' => $last_name ), array( 'field_id' => 2, 'user_id' => $user_id ) );
    // }

    // if (!empty($first_name) || !empty($last_name)) {
    //   $full_name = $first_name . ' ' . $last_name;
    //   $updated_buddy_boss_full_name = $wpdb->update( $buddy_boss_profile_table_name, array( 'value' => $full_name ), array( 'field_id' => 3, 'user_id' => $user_id ) );
    //   $updated_wp_display_name =  wp_update_user( array( 'ID' => $user_id, 'display_name' ) );
    // }

    // if (!empty($new_phone)) {
    //   $updated_phone = update_user_meta( $user_id, 'phone', $new_phone );
    // }

    // if (!empty($new_email)) {
    //   $updated_email = wp_update_user( array( 'ID' => $user_id, 'user_email' => $new_email ) );
    // }

    // return new WP_REST_Response( array(
    //   'message'=>'User details updated successfuly'
    // ), 200 );
  }

  public function get_items_permissions_check( $request ) {}
  public function get_item_permissions_check( $request ) {}
  public function create_item_permissions_check( $request ) {}
  public function update_item_permissions_check( $request ) {}
  public function delete_item_permissions_check( $request ) {}

  protected function prepare_item_for_database( $request ) {}
  public function prepare_item_for_response( $item, $request ) {}
  public function get_collection_params() {}
}
